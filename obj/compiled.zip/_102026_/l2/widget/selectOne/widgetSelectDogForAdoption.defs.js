"use strict";
/// <mls shortName="widgetSelectDogForAdoption" project="102026" enhancement="_blank" folder="widget/selectOne" />
