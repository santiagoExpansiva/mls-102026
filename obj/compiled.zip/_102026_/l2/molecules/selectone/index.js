/// <mls shortName="index" project="102026" enhancement="_blank" folder="molecules/selectone" />
export const widgetDefinition = {
    name: "numberInput",
    description: "Campo para inserir um número",
    properties: [
        { name: "value", type: "number" }
    ]
};
