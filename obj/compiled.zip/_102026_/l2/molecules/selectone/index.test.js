/// <mls shortName="index" project="102026" enhancement="_blank" folder="molecules/selectone" />
export const integrations = [];
export const tests = [];
