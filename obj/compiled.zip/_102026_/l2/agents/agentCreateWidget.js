/// <mls shortName="agentCreateWidget" project="102026" enhancement="_blank" folder="agents" />
import { svg_agent } from '/_100554_/l2/aiAgentBase.js';
import { preferModelType, getPromptByHtml } from '/_100554_/l2/aiPrompts.js';
import { getNextPendingStepByAgentName, getNextInProgressStepByAgentName, getStepById, updateStepStatus, calculateStepsStatistics, getInteractionStepId, } from "/_100554_/l2/aiAgentHelper.js";
import { startNewAiTask, executeNextStep, startNewInteractionInAiTask, addNewStep } from "/_100554_/l2/aiAgentOrchestration.js";
import { collabImport } from '/_100554_/l2/collabImport.js';
import '/_102026_/l2/widgetClarificationNewWidget.js';
const agentName = "agentCreateWidget";
const widgetPrefix = "widget";
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "criação de novos componentes UI, web components, widgets, estes widgets podem futuramente serem incluidos em uma página html",
        visibility: "public",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async beforeClarification(context, stepId) {
            return _beforeClarification(context, stepId);
        },
        async afterClarification(context, stepId, data) {
            return _afterClarification(context, stepId, data);
        }
    };
}
;
const _beforePrompt = async (context) => {
    const taskTitle = "Planning";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        // using temporary context, create a new task
        const inputs = await getPrompts(context.message.content, null);
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
    }
    else {
        const step = getNextPendingStepByAgentName(context.task, agentName);
        if (!step) {
            throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
        }
        context = await updateStepStatus(context, step.stepId, "in_progress");
        const inputs = await getPrompts(step.prompt, step.rags);
        await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
    }
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No pending interaction found.`);
    const { flexible } = calculateStepsStatistics([step], true);
    if (flexible > 0)
        throw new Error(`[${agentName}] afterPrompt: error, Flexible step found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    await executeNextStep(context);
};
const _beforeClarification = async (context, stepId) => {
    if (!context.task)
        throw new Error("[_beforeClarification] Invalid context.task");
    const step = getStepById(context.task, stepId);
    if (!step)
        throw new Error(`[_beforeClarification] Invalid step: ${stepId} on task: ${context.task.PK}`);
    const element = prepareHtmlClarification(step.json, context.task.PK, stepId, '');
    return element;
};
const _afterClarification = async (context, stepId, data) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    if (!data.json)
        throw new Error("Invalid json after clarification");
    const step = getStepById(context.task, stepId);
    if (!step) {
        throw new Error(`[${agentName}] _afterClarification: No found step: ${stepId} for this agent.`);
    }
    const interactionId = getInteractionStepId(context.task, step.stepId);
    if (!interactionId)
        throw new Error("[_afterClarification] Not found interactionId in pending step");
    const payload = getStepById(context.task, interactionId);
    if (!payload || payload.type !== "agent")
        throw new Error("[_afterClarification] Clarification or tool step not bellow a agent");
    const promptUser = payload.interaction?.input.find((input) => input.type === 'human')?.content || '';
    const rc = {
        prompt: promptUser,
        json: data.json
    };
    const newStep = {
        agentName: 'agentCreateWidget2',
        prompt: JSON.stringify(rc),
        status: 'pending',
        stepId: step.stepId + 1,
        interaction: null,
        nextSteps: null,
        rags: null,
        type: 'agent'
    };
    await addNewStep(context, step.stepId, [newStep]);
};
export async function getPrompts(prompt, rags) {
    if (!prompt || prompt.length < 3)
        throw new Error("Invalid Prompt");
    const comp = await getDefinitions(102026);
    const data = {
        mode: preferModelType("translate"),
        widgetPrefix: widgetPrefix,
        componentDef: JSON.stringify(comp),
        humanPrompt: prompt
    };
    const prompts = await getPromptByHtml({ project: 102026, shortName: agentName, folder: '', data });
    return prompts;
}
async function getDefinitions(project) {
    const ret = {};
    let array = [];
    Object.keys(mls.stor.files).forEach((key) => {
        const f = mls.stor.files[key];
        if (!f ||
            f.project !== project ||
            f.extension !== '.ts' ||
            !f.folder.startsWith('widget/') ||
            f.shortName !== 'index')
            return;
        array.push(f);
    });
    for await (const f of array) {
        const { project, folder, shortName } = f;
        const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, '.ts');
        const m = await collabImport({ project, folder, shortName });
        if (!m || !m.widgetDefinition)
            return;
        const r = { ...m.widgetDefinition };
        r.key = key;
        ret[r.name] = r;
    }
    return ret;
}
function prepareHtmlClarification(json, taskId, stepId, clarificationMessage) {
    const div = document.createElement('div');
    const clarificationData = {
        clarificationMessage,
        stepId: stepId,
        taskId: taskId,
        json: json
    };
    const clariEl = document.createElement('widget-clarification-new-widget-102026');
    if (json && typeof json === 'object')
        clariEl.data = clarificationData;
    else
        clariEl.setAttribute('error', 'Invalid clarification return');
    div.appendChild(clariEl);
    return div;
}
/*
{
    "widget": "selectOne",
    "key": "102026_2_widget/selectOne/index.ts",
    "reason": "Widget para seleção de um único item: permite escolher qual cachorro da lista você deseja adotar."
}
*/
