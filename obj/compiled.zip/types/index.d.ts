declare module "_102026_designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102026_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
