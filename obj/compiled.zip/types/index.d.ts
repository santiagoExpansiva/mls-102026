declare module "_102026_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_/l2/designSystem" {
    import { IDesignSystemTokens } from '/_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102026_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102026_/l2/widgetClarificationNewWidget.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_/l2/widgetClarificationNewWidget" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class WcClarificationPlannerNewWidget100554 extends StateLitElement {
        private ICABASEPROJECT;
        private folder;
        data?: ClarificationData;
        error?: string;
        develpoment?: boolean;
        mode: 'readonly' | 'write';
        inputTag?: HTMLInputElement;
        widgetNameError?: HTMLInputElement;
        render(): any;
        private renderResume;
        private renderParentClass;
        private renderWidgetName;
        private renderProperties;
        private renderRequirements;
        private createTagName;
        private removeTrailingPattern;
        private createParentName;
        private handleWidgetNameInput;
        private handleTagNameChange;
        private handleParentInput;
        private handleRqVisualInput;
        private handleRqFunctionalInput;
        private handleCancel;
        private handleOk;
        private handleAction;
        private getBase;
        private setDevelpoment;
    }
    interface ClarificationData {
        json: Clarification[] | undefined;
        taskId: string;
        stepId: number;
        clarificationMessage: string;
    }
    type Clarification = ClarificationResume | ClarificationWidgetName | ClarificationParentName | ClarificationProperties | ClarificationRequirements;
    interface ClarificationBase {
        sectionName: string;
        description: string;
    }
    interface ClarificationResume extends ClarificationBase {
    }
    interface ClarificationWidgetName extends ClarificationBase {
        widgetName: string;
        tagName: string;
        folder: string;
        project: number;
    }
    interface ClarificationParentName extends ClarificationBase {
        widgetName: string;
    }
    interface ClarificationProperties extends ClarificationBase {
        properties: {
            propertyName: string;
            description: string;
            isEssencial: string;
        }[];
    }
    interface ClarificationRequirements extends ClarificationBase {
        functionalRequirements: string[];
        visualRequirements?: string[];
    }
}
declare module "_102026_/l2/widgetPlaygroundState.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_/l2/widgetPlaygroundState" {
    import { LitElement } from 'lit';
    export class WidgetPlaygroundState extends LitElement {
        state: string;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private initStatePlayground;
    }
}
declare module "_102026_/l2/agents/agentCreateWidget.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_/l2/agents/agentCreateWidget" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    import '/_102026_/l2/widgetClarificationNewWidget.js';
    export function createAgent(): IAgent;
    export function getPrompts(prompt: string | undefined, rags: string[] | null): Promise<mls.msg.IAMessageInputType[]>;
}
declare module "_102026_/l2/agents/agentCreateWidget2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_/l2/agents/agentCreateWidget2" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function getPrompts(obj: any, prompt: string | undefined): Promise<mls.msg.IAMessageInputType[]>;
}
declare module "_102026_/l2/agents/agentCreateWidget3.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_/l2/agents/agentCreateWidget3" {
    import { IAgent } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function getPrompts(shortName: string, project: number, folder: string): Promise<mls.msg.IAMessageInputType[]>;
}
declare module "_102026_/l2/molecules/inputnumber/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_/l2/molecules/inputnumber/index" {
    export const widgetDefinition: {
        name: string;
        description: string;
        properties: {
            name: string;
            type: string;
        }[];
    };
}
declare module "_102026_/l2/molecules/selectone/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102026_/l2/molecules/selectone/index" {
    export const widgetDefinition: {
        name: string;
        description: string;
        properties: {
            name: string;
            type: string;
        }[];
    };
}
