/// <mls shortName="index" project="102026" enhancement="_blank" folder="widget/selectOne" />

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];